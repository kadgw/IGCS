Injectable camera for Cyberpunk 2077
============================

Current supported game version: v1.0.10+  
Credits: Otis_Inf &  Jim2Point0. Special thanks: Etra  
Binaries: https://www.patreon.com/Otis_Inf

### IMPORTANT
This is the only public location of this mod. You're not allowed to upload the mod to other sites like Nexus.
If you see the mod being added there, please report it. Thanks.

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
