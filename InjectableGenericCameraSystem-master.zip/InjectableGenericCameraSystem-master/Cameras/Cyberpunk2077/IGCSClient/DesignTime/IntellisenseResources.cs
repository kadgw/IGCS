﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IGCSClient
{
	/// <summary>
	/// Required class for intellisense in wpf designer for ModernWPF
	/// </summary>
	public class IntellisenseResources : ModernWpf.DesignTime.IntellisenseResourcesBase
	{
		public IntellisenseResources()
		{
		}
	}
}
