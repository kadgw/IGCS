Injectable camera for Deus Ex: Mankind Divided
============================

Current supported game version: v1.19+
Camera version: 1.0.4  
Credits: Otis_Inf. Special thanks to K-putt and Jim2Point0  

For updates and support: https://www.patreon.com/Otis_Inf

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
