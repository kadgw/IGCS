#pragma once

#include "stdafx.h"
#include <d3d11.h> 

namespace IGCS::D3D11Hooker
{
	void initializeHook();
}