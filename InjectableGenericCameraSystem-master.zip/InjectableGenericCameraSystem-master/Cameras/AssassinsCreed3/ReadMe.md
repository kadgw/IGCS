Injectable camera for Assassin's Creed 3
============================

Current supported game version: Latest UPlay version  
Credits: Otis_Inf. Thanks to Jim2Point0 for the CT which is used as a starting point to hunt down the hooks for the interceptors.  
Accompanying HUD toggle: https://mega.nz/#!kdhT3KIQ!iPW6XIlrmQL4nLxCOSJj8bsZHEdeHaL5n-9r_zQIQ0A  

For updates and support: https://www.patreon.com/Otis_Inf
