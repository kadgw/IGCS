Injectable camera for Dying Light
============================

Current supported game version: v1.1.16+  
Camera version: 1.0.1  
Credits: Otis_Inf. Thanks to Jim2Point0 for LoD override.

For updates and support: https://www.patreon.com/Otis_Inf

### How to use
Read the enclosed readme.txt for details, really! Run the game as **administrator** otherwise it won't work.

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
