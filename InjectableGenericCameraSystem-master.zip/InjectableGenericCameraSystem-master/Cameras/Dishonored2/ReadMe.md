Injectable camera for Dishonored 2 and Dishonored: Death of the Outsider
============================

Current supported game version: v1.77.9+ (Dishonored 2)  and v1.145+ (Dishonored: death of the outsider)  
Camera version: 1.0.2  
Credits: Otis_Inf.  

For updates and support: https://www.patreon.com/Otis_Inf

### Features
- Camera control: (Also in cut scenes)
	- FoV control
	- Free unlimited camera movement and rotation 
- Ansel everywhere
- Ansel movement fixed
- Ansel now works in a windowed game

NOTE: If you enable Ansel using Alt-F2, you shouldn't enable this camera. 

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
