Injectable camera for DOOM 
============================

Current supported game version: v6.66 (latest, steam)  
Credits: Otis_Inf  

For updates and support: https://www.patreon.com/Otis_Inf


### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
