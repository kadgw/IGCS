Injectable camera for Batman Arkham Knight
============================

Current supported game version: v1.6.2.0  
Credits: Otis_Inf / One3rd / Jim2Point0  

For updates and support: https://www.patreon.com/Otis_Inf

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
