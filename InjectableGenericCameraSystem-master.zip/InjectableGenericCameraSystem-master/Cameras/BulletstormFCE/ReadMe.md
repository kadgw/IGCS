Injectable camera for Bulletstorm Full Clip Edition
============================

Current supported game version: v1.1+
Camera version: 1.0.2  
Credits: Otis_Inf. 

For updates and support: https://www.patreon.com/Otis_Inf

### Acknowledgements
This camera uses [MinHook](https://github.com/TsudaKageyu/minhook) by Tsuda Kageyu.
